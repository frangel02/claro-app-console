# claro App notes


 - react : "^17.0.1"
 - node : "16.13.0"
### `npm install`

Para correr el proyecto 
### `npm start`

Runs the app in the development mode.\
Open [http://localhost:3000](http://localhost:3000) to view it in the browser.
