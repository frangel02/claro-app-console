import com.github.javaparser.StaticJavaParser;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.body.FieldDeclaration;
import com.github.javaparser.ast.body.MethodDeclaration;
import com.github.javaparser.ast.visitor.VoidVisitorAdapter;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;



public class JavaClassAnalyzer {

    public static void main(String[] args) throws FileNotFoundException {
        if (args.length != 1) {
            System.err.println("Usage: JavaClassAnalyzer <file>");
            System.exit(1);
        }

        File file = new File(args[0]);

        // Read the file and create a string with its contents
        Scanner scanner = new Scanner(file);
        StringBuilder stringBuilder = new StringBuilder();
        while (scanner.hasNextLine()) {
            stringBuilder.append(scanner.nextLine());
            stringBuilder.append("\n");
        }
        scanner.close();

        String code = stringBuilder.toString();

        // Parse the code and create an AST
        CompilationUnit compilationUnit = StaticJavaParser.parse(code);

        // Print the name of the public class
        compilationUnit.getTypes().forEach(typeDeclaration -> {
            if (typeDeclaration.isPublic()) {
                System.out.println("Class name: " + typeDeclaration.getName());
            }
        });

        // Print the fields of the class
        System.out.println("Fields:");
        compilationUnit.accept(new VoidVisitorAdapter<Void>() {
            @Override
            public void visit(FieldDeclaration fieldDeclaration, Void arg) {
                System.out.println("- " + fieldDeclaration.getVariables().get(0).getNameAsString() + " : " + fieldDeclaration.getElementType().toString());
                super.visit(fieldDeclaration, arg);
            }
        }, null);

        // Print the methods of the class
        System.out.println("Methods:");
        compilationUnit.accept(new VoidVisitorAdapter<Void>() {
            @Override
            public void visit(MethodDeclaration methodDeclaration, Void arg) {
                System.out.println("- " + methodDeclaration.getName() + methodDeclaration.getParameters());
                super.visit(methodDeclaration, arg);
            }
        }, null);
    }
}
