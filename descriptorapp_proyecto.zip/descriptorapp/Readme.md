

## Aplicacion para validar las clases Java mediante linea de comando y pasarlo por archivo de texto

hay una carpeta que contiene el jar generado esta carpeta contiene el txt y el jar  solo es ejecutarlo con el comando

    java -jar descriptorapp.jar ClaroTest.txt

